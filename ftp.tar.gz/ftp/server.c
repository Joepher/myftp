#include<arpa/inet.h>
#include<dirent.h>
#include<fcntl.h>
#include<linux/if.h>
#include<netdb.h>
#include<netinet/in.h>
#include<setjmp.h>
#include<signal.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/ioctl.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/wait.h>
#include<unistd.h>

#define ERR_ACCEPT "ER accept failed\n"
#define ERR_BIND "ER bind failed\n"
#define ERR_CMDREAD "ER command reading failed\n"
#define ERR_CMD "ER wrong command\n"
#define ERR_CONNECT "ER connect failed\n"
#define ERR_CREATE "ER create socket failed\n"
#define ERR_PORTEXIT "ER port has already been set\n"
#define ERR_PORTNONE "ER port has not been set\n"

#define RESPONSE_OK "OK"
#define RESPONSE_ER "ER"

#define BUF_SIZE 1024
#define CMD_LEN 10
#define CMDARG_LEN 20
#define CONTROL_PORT 21
#define DATA_PORT 20
#define PATH_LEN 200
#define IP_LEN 4
#define RECODE_LEN 100
#define TRUE 1

union ipu
{
	long ip;
	unsigned char ipchar[IP_LEN];
};

int cmd_prt(int control_sockfd,int data_socket,char *client_data_port,struct sockaddr_in CLIENT_ADDR);
void cmd_dir(int data_socket);
void cmd_get(int data_socket,char *fileName);
void cmd_bye(int control_socket,int data_socket,int control_sockfd);
long getlocalhostip();

int main()
{
	char cmd[CMD_LEN],cmd_arg[CMDARG_LEN];
	union ipu iptest;
	struct sockaddr_in control_address,data_address;
	struct sockaddr_in CLIENT_ADDR;
	int control_socket,data_socket,control_sockfd;
	int control_len,data_len,CLIENT_LEN;
	int commandValue;
	int readCmdValue;
	int cmdExitStat;
	pid_t pid;
	
	control_socket=socket(AF_INET,SOCK_STREAM,0);
	if(control_socket<0)
	{
		perror(ERR_CREATE);
		exit(0);
	}
	
	control_address.sin_family=AF_INET;
	control_address.sin_addr.s_addr=INADDR_ANY;
	control_address.sin_port=htons(CONTROL_PORT);
	control_len=sizeof(control_address);
	
	if(bind(control_socket,(struct sockaddr *)&control_address,control_len)<0)
	{
		perror(ERR_BIND);
		exit(0);
	}
	
	CLIENT_LEN=sizeof(CLIENT_ADDR);
	memset(&CLIENT_ADDR,0,CLIENT_LEN);
	
	listen(control_socket,5);
	iptest.ip=getlocalhostip();
	printf("server_address: %u.%u.%u.%u\tcontrol_port: %u\n",iptest.ipchar[0],iptest.ipchar[1],iptest.ipchar[2],iptest.ipchar[3],ntohs(control_address.sin_port));
	printf("server started successfully. waiting for connection...\n");
	
	while(TRUE)
	{
		control_sockfd=accept(control_socket,(struct sockaddr *)&CLIENT_ADDR,(int *)&CLIENT_LEN);
		
		if(control_sockfd<0)
			perror(ERR_ACCEPT);
		else
		{
			signal(SIGCHLD,SIG_IGN);
			
			if((pid=fork())<0)
				printf("fork error\n");
			if(pid==0)
			{
				printf("OK. connection accepted. new connection from %s,port %d\n",inet_ntoa(CLIENT_ADDR.sin_addr),ntohs(CLIENT_ADDR.sin_port));
				
				cmdExitStat=1;
				while(cmdExitStat==1)
				{
					memset(cmd,0,sizeof(cmd));
					readCmdValue=0;
					readCmdValue=read(control_sockfd,cmd,sizeof(cmd));
				
					if(readCmdValue<0)
						perror(ERR_CMDREAD);
					else if(readCmdValue==0)
					{
						printf("connection closed... socket: %d\tpid:%d\n",control_sockfd,getpid());
						break;
					}
					else
					{
						if(strcmp(cmd,"PRT")==0)
							commandValue=1;
						else if(strcmp(cmd,"DIR")==0)
							commandValue=2;
						else if(strcmp(cmd,"GET")==0)
							commandValue=3;
						else if(strcmp(cmd,"BYE")==0)
							commandValue=4;
						else
							commandValue=5;
							
						switch(commandValue)
						{
							case 1:
								data_socket=socket(AF_INET,SOCK_STREAM,0);
								data_address.sin_family=AF_INET;
								data_address.sin_addr.s_addr=INADDR_ANY;
								data_address.sin_port=htons(DATA_PORT);
								data_len=sizeof(data_address);
								bind(data_socket,(struct sockaddr *)&data_address,data_len);
							
								memset(cmd_arg,0,sizeof(cmd_arg));
								read(control_sockfd,cmd_arg,sizeof(cmd_arg));
								data_socket=cmd_prt(control_sockfd,data_socket,cmd_arg,CLIENT_ADDR);
							break;
							
							case 2:
								cmd_dir(data_socket);
							break;
							
							case 3:
								memset(cmd_arg,0,sizeof(cmd_arg));
								read(control_sockfd,cmd_arg,sizeof(cmd_arg));
								cmd_get(data_socket,cmd_arg);
							break;
							
							case 4:
								printf("OK. command BYE.\n");
								cmd_bye(control_socket,data_socket,control_sockfd);
								cmdExitStat=0;
							break;
							
							case 5:
								printf(ERR_CMD);
							break;
						}
					}
				}
				break;
			}
			else
			{
				printf("\nclient socket: %d\tpid: %d\n",control_sockfd,pid);
			}
		}	
	}
	exit(0);
}

int cmd_prt(int control_sockfd,int data_socket,char *client_data_port,struct sockaddr_in CLIENT_ADDR)
{
	struct sockaddr_in client_address;
	int client_len;
	int result;
	
	client_len=sizeof(client_address);
	
	memset(&client_address,0,client_len);
	client_address.sin_family=AF_INET;
	client_address.sin_addr.s_addr=CLIENT_ADDR.sin_addr.s_addr;
	client_address.sin_port=htons((int)*client_data_port);
	
	result=connect(data_socket,(struct sockaddr *)&client_address,client_len);
	if(result<0)
	{
		perror("conncet to client failed.\n");
		return;
	}
	else
	{
		printf("connect to client successed.\n");
		return data_socket;
	}
}

int myfilter(const struct dirent *pdir)
{
	if((strcmp(pdir->d_name,".")==0) || (strcmp(pdir->d_name,"..")==0))
		return 0;
	else
		return 1;
}

void cmd_dir(int data_socket)
{
	struct dirent **nameList;
	struct stat fileStat;
	char currentDirPath[PATH_LEN];
	char responseCode[RECODE_LEN];
	char tempFileName[]="tmp_file.XXXXXX";
	char buf[BUF_SIZE];
	int fileSize;
	int fileCounter;
	int fd;
	int i;
	
	fd=mkstemp(tempFileName);
	unlink(tempFileName);
	
	memset(currentDirPath,0,sizeof(currentDirPath));
	getcwd(currentDirPath,sizeof(currentDirPath));
	strcat(currentDirPath,"/serverFile");
	
	fileCounter=scandir(currentDirPath,&nameList,myfilter,alphasort);
	if(fileCounter<0)
	{
		memset(responseCode,0,sizeof(responseCode));
		strcpy(responseCode,RESPONSE_ER);
		strcat(responseCode," file path loading error, please check it...\n");
		write(data_socket,responseCode,sizeof(responseCode));
	}
	else
	{
		memset(responseCode,0,sizeof(responseCode));
		strcpy(responseCode,RESPONSE_OK);
		write(data_socket,responseCode,sizeof(responseCode));
		write(data_socket,&fileCounter,sizeof(int));
		
		for(i=0;i<fileCounter;i++)
		{
			write(fd,nameList[i]->d_name,strlen(nameList[i]->d_name));
			write(fd,"\n",strlen("\n"));
		}
		
		fstat(fd,&fileStat);
		fileSize=fileStat.st_size;
		lseek(fd,0,SEEK_SET);
		
		if(fileSize>BUF_SIZE)
		{
			while(fileSize>0)
			{
				read(fd,buf,BUF_SIZE);
				write(data_socket,buf,strlen(buf));
				fileSize -= BUF_SIZE;
			}
		}
		else
		{
			read(fd,buf,fileSize);
			write(data_socket,buf,fileSize);
		}
		close(fd);
	}
}

void cmd_get(int data_socket,char*fileName)
{
	struct stat fileStat;
	char currentFilePath[PATH_LEN+1];
	char responseCode[RECODE_LEN+1];
	char buf[BUF_SIZE];
	long fileSize;
	int fd;
	
	//memset(currentFilePath,0,sizeof(currentFilePath));
	bzero(currentFilePath,sizeof(currentFilePath));
	getcwd(currentFilePath,sizeof(currentFilePath));
	strcat(currentFilePath,"/serverFile/");
	strcat(currentFilePath,fileName);
	
	fd=open(currentFilePath,O_RDONLY,S_IREAD);
	if(fd<0)
	{
		//memset(responseCode,0,sizeof(responseCode));
		bzero(responseCode,sizeof(responseCode));
		strcpy(responseCode,RESPONSE_ER);
		strcat(responseCode," file not exit, please check it...\n");
		write(data_socket,responseCode,sizeof(responseCode));
	}
	else
	{
		//memset(responseCode,0,sizeof(responseCode));
		bzero(responseCode,sizeof(responseCode));
		strcpy(responseCode,RESPONSE_OK);
		write(data_socket,responseCode,sizeof(responseCode));
		
		fstat(fd,&fileStat);
		fileSize=(long)fileStat.st_size;
		write(data_socket,&fileSize,sizeof(long));
		
		//memset(buf,0,BUF_SIZE);
		bzero(buf,BUF_SIZE);
		if(fileSize>BUF_SIZE)
		{
			while(fileSize>BUF_SIZE)
			{
				read(fd,buf,BUF_SIZE);
				write(data_socket,buf,strlen(buf));
				bzero(buf,sizeof(buf));
				fileSize -= BUF_SIZE;
			}
		}
		else
		{
			read(fd,buf,fileSize);
			write(data_socket,buf,fileSize);
		}
		close(fd);
	}
}

void cmd_bye(control_socket,data_socket,control_sockfd)
{
	close(control_socket);
	close(data_socket);
	close(control_sockfd);
	exit(0);
}

long getlocalhostip()
{
	int  MAXINTERFACES=16;
	long ip;
	int fd, intrface, retn = 0;
	struct ifreq buf[MAXINTERFACES];
	struct ifconf ifc;
	ip = -1;
	if((fd = socket (AF_INET, SOCK_DGRAM, 0)) >= 0)
	{
		ifc.ifc_len = sizeof buf;
		ifc.ifc_buf = (caddr_t) buf;
		if (!ioctl (fd, SIOCGIFCONF, (char *) &ifc))
		{
			intrface = ifc.ifc_len / sizeof (struct ifreq);
			while (intrface-- > 0)
			{
				if (!(ioctl (fd, SIOCGIFADDR, (char *) &buf[intrface])))
				{
					ip=inet_addr( inet_ntoa( ((struct sockaddr_in*)(&buf[intrface].ifr_addr))->sin_addr) );
					break;
				}
			}
		}
		close(fd);
	}
	return ip;
}
