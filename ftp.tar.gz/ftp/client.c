#include<dirent.h>
#include<fcntl.h>
#include<netdb.h>
#include<netinet/in.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/socket.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<unistd.h>

#define ERR_ACCEPT "ER accept failed\n"
#define ERR_BIND "ER bind failed\n"
#define ERR_CMD "ER wrong command\n"
#define ERR_CONNECT "ER connect failed\n"
#define ERR_CREATE "ER create socket failed\n"
#define ERR_PORTEXIT "ER port has already been set\n"
#define ERR_PORTNONE "ER port has not been set\n"

#define BUF_SIZE 1024
#define CONTROL_PORT 1874
#define CMD_LEN 10
#define CMDARG_LEN 20
#define PATH_LEN 200
#define RECODE_LEN 100
#define TRUE 1

char cmd[CMD_LEN],cmd_arg[CMDARG_LEN];

int cmd_prt(int control_socket,int data_socket,char *data_port);
void cmd_dir(int control_socket,int data_sockfd);
void cmd_get(int control_socket,int data_sockfd,char *fileName);
void cmd_bye(int control_socket,int data_socket,int data_sockfd);

int main(int argc,char *argv[])
{
	struct sockaddr_in control_address,server_address;
	int control_socket,data_socket,data_sockfd;
	int control_len,server_len;
	int cmd_len,cmd_arg_len;
	int result;
	int port_stat=0;
	
	control_socket=socket(AF_INET,SOCK_STREAM,0);
	if(control_socket<0)
	{
		perror(ERR_CREATE);
		exit(0);
	}
		
	control_address.sin_family=AF_INET;
	control_address.sin_addr.s_addr=htons(INADDR_ANY);
	control_address.sin_port=htons(0);
	control_len=sizeof(control_address);
	
	if(bind(control_socket,(struct sockaddr *)&control_address,control_len)<0)
	{
		perror(ERR_BIND);
		exit(0);
	}
	
	data_socket=socket(AF_INET,SOCK_STREAM,0);
	
	server_address.sin_family=AF_INET;
	server_address.sin_addr.s_addr=inet_addr(argv[1]);
	server_address.sin_port=htons(atoi(argv[2]));
	server_len=sizeof(server_address);
	
	result=connect(control_socket,(struct sockaddr *)&server_address,server_len);
	
	if(result<0)
	{
		perror(ERR_CONNECT);
		exit(0);
	}
	
	while(TRUE)
	{
		memset(cmd,0,CMD_LEN);
		memset(cmd_arg,0,CMDARG_LEN);
		
		printf("CLIENT> ");
		scanf("%s",cmd);
		cmd_len=strlen(cmd);
		
		if(strcmp(cmd,"PRT")==0)
		{
			if(port_stat==0)
			{
				printf("PORT> ");
				scanf("%s",cmd_arg);
				data_sockfd=cmd_prt(control_socket,data_socket,cmd_arg);
				port_stat=1;
			}
			else
				printf("%s",ERR_PORTEXIT);
		}
		else if(strcmp(cmd,"DIR")==0)
		{
			if(port_stat==1)
				cmd_dir(control_socket,data_sockfd);
			else
				perror(ERR_PORTNONE);
		}
		else if(strcmp(cmd,"GET")==0)
		{
			if(port_stat==1)
			{
				scanf("%s",cmd_arg);
				cmd_get(control_socket,data_sockfd,cmd_arg);
			}
			else
				perror(ERR_PORTNONE);
		}
		else if(strcmp(cmd,"BYE")==0)
			cmd_bye(control_socket,data_socket,data_sockfd);
		else
			printf(ERR_CMD);
	}
	exit(0);
}

int cmd_prt(int control_socket,int data_socket,char *data_port)
{
	struct sockaddr_in data_address;
	int data_len;
	int data_sockfd;
	
	data_address.sin_family=AF_INET;
	data_address.sin_addr.s_addr=htons(INADDR_ANY);
	data_address.sin_port=htons((int)*data_port);
	data_len=sizeof(data_address);
	bind(data_socket,(struct sockaddr *)&data_address,data_len);
	
	write(control_socket,cmd,sizeof(cmd));
	write(control_socket,cmd_arg,sizeof(cmd_arg));
	
	listen(data_socket,1);
	
	data_sockfd=accept(data_socket,(struct sockaddr *)0,(int *)0);
	if(data_sockfd<0)
	{
		perror(ERR_ACCEPT);
		return;
	}
	else
	{
		printf("server connect succedded.\n");
		return data_sockfd;
	}
}

void cmd_dir(int control_socket,int data_sockfd)
{
	char responseCode[RECODE_LEN];
	char buf[BUF_SIZE];
	int fileCounter;
	int i;
	
	write(control_socket,cmd,sizeof(cmd));
	
	read(data_sockfd,responseCode,sizeof(responseCode));
	bzero(buf,BUF_SIZE);
	if(strcmp(responseCode,"OK")==0)
	{
		read(data_sockfd,&fileCounter,sizeof(int));
		read(data_sockfd,buf,sizeof(buf));
		printf("\n%s\n",buf);
	}
	else
		printf("%s\n",responseCode);
}

void cmd_get(int control_socket,int data_sockfd,char *fileName)
{
	char currentFilePath[PATH_LEN];
	char responseCode[RECODE_LEN];
	char buf[BUF_SIZE];
	long fileSize;
	int fd;
	
	write(control_socket,cmd,sizeof(cmd));
	write(control_socket,cmd_arg,sizeof(cmd_arg));
	
	bzero(responseCode,sizeof(responseCode));
	read(data_sockfd,responseCode,sizeof(responseCode));
	if(strcmp(responseCode,"OK")==0)
	{
		//memset(currentFilePath,0,sizeof(currentFilePath));
		bzero(currentFilePath,sizeof(currentFilePath));
		getcwd(currentFilePath,sizeof(currentFilePath));
		strcat(currentFilePath,"/clientFile/");
		strcat(currentFilePath,fileName);
	
		fd=open(currentFilePath,O_RDWR|O_CREAT,S_IREAD|S_IWRITE);
		if(fd<0)
			printf("open file %s failed.\n",currentFilePath);
		else
		{
			//memset(buf,0,BUF_SIZE);
			bzero(buf,BUF_SIZE);
			read(data_sockfd,&fileSize,sizeof(long));
			
			if(fileSize>BUF_SIZE)
			{
				while(fileSize>0)
				{
					read(data_sockfd,buf,BUF_SIZE);
					write(fd,buf,strlen(buf));
					fileSize -= BUF_SIZE;
					bzero(buf,sizeof(buf));
				}
			}
			else
			{
				read(data_sockfd,buf,fileSize);
				write(fd,buf,fileSize);
			}
			close(fd);
			printf("\ndownload completed.\n");
		}
	}
	else
		printf("%s\n",responseCode);
}

void cmd_bye(int control_socket,int data_socket,int data_sockfd)
{
	close(control_socket);
	close(data_socket);
	close(data_sockfd);
	printf("connection closed\n");
	exit(0);
}
